package cn.m4399.game;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import cn.m4399.operate.OperateCenter;
import cn.m4399.operate.OperateCenter.OnCheckFinishedListener;
import cn.m4399.operate.OperateCenter.OnDownloadListener;
import cn.m4399.operate.OperateCenter.OnLoginFinishedListener;
import cn.m4399.operate.OperateCenter.OnQuitGameListener;
import cn.m4399.operate.OperateCenter.OnRechargeFinishedListener;
import cn.m4399.operate.OperateCenterConfig;
import cn.m4399.operate.OperateCenterConfig.PopLogoStyle;
import cn.m4399.operate.OperateCenterConfig.PopWinPosition;
import cn.m4399.operate.UpgradeInfo;
import cn.m4399.operate.User;

public class MainActivity extends Activity {
	private static final String GAME_KEY = "40027";
	public static final String TAG = "4399SDK-GameActivity";
	public static final String T_PREFFIX = "【DEMO】";
	private static final int MAX_MARK_LENTH = 32;	//mark最大长度
	
	// SDK界面支持的四种方向配置
	public static final Integer[] ORIENTATION = new Integer[] { 
		ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE, // 0，横屏
		ActivityInfo.SCREEN_ORIENTATION_PORTRAIT, // 1，竖屏
		ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE, // 6，横屏180度旋转
		ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT // 7，竖屏180度旋转
	};
	
	public static final String[] ORIENTATION_NAMES = new String[] {
		"横屏",
		"竖屏",
		"横屏180度",
		"竖屏180度"
	};
	
	// 悬浮窗有四种风格，对应了一个数组
	public static final String[] POP_STYLE_NAMES = new String[] { "黄色", "数字", "豆娃", "熊猫" };
	public static final PopLogoStyle [] POP_STYLES = new PopLogoStyle[] {
		PopLogoStyle.POPLOGOSTYLE_ONE,
		PopLogoStyle.POPLOGOSTYLE_TWO,
		PopLogoStyle.POPLOGOSTYLE_THREE,
		PopLogoStyle.POPLOGOSTYLE_FOUR,
	};
	
	// 服务器
	public static final String[] SERVERS = new String[] {"1", "2", "3", "4", "5", "6", "7"};

	OperateCenter mOpeCenter;
	SharedPreferences mSp;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		mSp = getSharedPreferences("sdk_sp", MODE_PRIVATE);
		// 设置DemoActivity的方向
		setDemoOrientation();

		setContentView(R.layout.m4399_demo_main);
		
		initOrientationSpinner();
		initPopStyleSpinner();

		// 初始化SDK
		initSDK();

		//显示SDK版本信息
		showSDKVersion();
	}

	private void initSDK() {
		// 游戏接入SDK；
		mOpeCenter = OperateCenter.getInstance();
		
		// 配置sdk属性,比如可扩展横竖屏配置
		OperateCenterConfig opeConfig = new OperateCenterConfig.Builder(this)
		    .setDebugEnabled(false)
		    .setOrientation(getOrientation())
			.setPopLogoStyle(getPopStylePreference())
			.setPopWinPosition(PopWinPosition.POS_LEFT)
			.setSupportExcess(true)
			.setGameKey(GAME_KEY)
			.build();
		mOpeCenter.setConfig(opeConfig);
		
		//初始化SDK，在这个过程中会读取各种配置和检查当前帐号是否在登录中
		//只有在init之后， isLogin()返回的状态才可靠
		mOpeCenter.init(MainActivity.this, new OperateCenter.OnInitGloabListener() {
			
			// 初始化结束执行后回调
			@Override
			public void onInitFinished(boolean isLogin, User userInfo) {
				String loginState = isLogin ? getString(R.string.logging) : getString(R.string.not_logging);
				assert(isLogin == mOpeCenter.isLogin());
				showInToast(loginState + ": " + userInfo);
			}

			// 注销帐号的回调， 包括个人中心里的注销和logout()注销方式
			@Override
			public void onUserAccountLogout(boolean fromUserCenter, int resultCode) {
				String tail = fromUserCenter ? "从用户中心退出" : "不是从用户中心退出";
				Log.d(TAG, "onUserAccountLogout resultCode: " + resultCode);
				showInToast(OperateCenter.getResultMsg(resultCode) + "(" + tail + ")");
			}

			// 个人中心里切换帐号的回调
			@Override
			public void onSwitchUserAccountFinished(User userInfo) {
				Log.d(TAG, "Switch Account: " + userInfo.toString());
				showInToast(userInfo.toString());
			}
		});
	}
	
    private void destroySDK() {
        if (mOpeCenter != null) {
            mOpeCenter.destroy();
            mOpeCenter = null;
        }
    }

	@Override
	protected void onDestroy() {
		super.onDestroy();
		destroySDK();
	}
	
	private void showSDKVersion() {
		TextView versionText = (TextView) findViewById(R.id.text_version);
		if (versionText != null) {
			versionText.setText("运营SDK v" + OperateCenter.getVersion()
					+"     gameKey : " + GAME_KEY);
		}
	}

	/**
	 * 测试悬浮窗
	 * 
	 * 为了在demo中能测试四种风格悬浮窗，使用Spinner选择悬浮窗风格， 并将选择保存在SharedPreferenced中。
	 * 实际接入时，可以直接用OperateCenterConfig
	 * .Builder(this)。setPopLogoStyle(PopLogoStyle.POPLOGOSTYLE_ONE)
	 * 
	 * 注意：Demo中选择了悬浮窗风格后，需要下次启动才能生效
	 * 
	 */
	private void initPopStyleSpinner() {
		Spinner spinner = (Spinner) findViewById(R.id.m4399_demo_pop_spinner);

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, POP_STYLE_NAMES);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner.setAdapter(adapter);

		spinner.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
				Log.d(TAG, POP_STYLE_NAMES[pos]);
				savePopStylePreference(pos);
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
			}
		});

		spinner.setSelection(mSp.getInt("pop_style", 0));
	}

	private PopLogoStyle getPopStylePreference() {
		int pos = mSp.getInt("pop_style", 0);
		return POP_STYLES[pos];
	}

	private void savePopStylePreference(int pos) {
		mSp.edit().putInt("pop_style", pos).commit();
	}
	
	/********************** 结束悬浮窗相关测试代码 ************************/

	/*
	 * 测试SDK界面的方向设置
	 * 
	 * 为了在Demo中测试横竖屏，提供Spinner控件设置方向配置，并保持着SharedPreference中
	 * 实际接入直接设置OperateCenterConfig
	 * .Builder(this)。setOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE)
	 * 
	 * 注意：横竖屏设置都需要重启Demo才能生效; 测试旋转屏幕时要开启“自动旋转屏幕”
	 */
	private void setDemoOrientation() {
		int ori = getOrientation();
		setRequestedOrientation(ori);
	}
	
	public void initOrientationSpinner() {
		Spinner spinner = (Spinner) findViewById(R.id.m4399_demo_ori_spinner);

		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, ORIENTATION_NAMES);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		spinner.setAdapter(adapter);

		spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
				Log.d(TAG, "Set orientation as " + ORIENTATION_NAMES[pos]);
				saveOrientation(pos);
			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {
			}
		});

		// 这里设置默认方向为横屏，SDK内部的默认方向也是
		spinner.setSelection(mSp.getInt("orientation", 0));
	}

	private int getOrientation() {
		int pos = mSp.getInt("orientation", 0);
		if (pos <0 || pos > 3)
			pos = 0;
		return ORIENTATION[pos];
	}

	private void saveOrientation(int pos) {
		mSp.edit().putInt("orientation", pos).commit();
	}

	/************ 结束横竖屏设置和测试代码 **************/

	// 登录
	public void onLoginButtonClicked(View view) {
		mOpeCenter.login(MainActivity.this, new OnLoginFinishedListener() {

			@Override
			public void onLoginFinished(boolean success, int resultCode, User userInfo) {
				String msg = OperateCenter.getResultMsg(resultCode) + ": " + userInfo;
				Log.d(TAG, "用户信息：" + userInfo);
				showInToast(msg);
			}
		});
		Log.d(TAG, "isLogin: " + mOpeCenter.isLogin());
	}

	public void onSwitchAccountButtonClicked(View view) {
		mOpeCenter.switchAccount(MainActivity.this, new OnLoginFinishedListener() {

			@Override
			public void onLoginFinished(boolean success, int resultCode, User userInfo) {
				Log.d(TAG, "Login: " + success + ", " + resultCode + ": " + userInfo.toString());
				String messageString = OperateCenter.getResultMsg(resultCode) + ": " + userInfo;
				Toast.makeText(MainActivity.this, T_PREFFIX + messageString, Toast.LENGTH_SHORT).show();
			}
		});
	}

	//当前帐号是否在登录状态（如果当前没有帐号在登录认为不在登录状态）
	public void onIsLoginButtonClicked(View view) {
		boolean isLogin = mOpeCenter.isLogin();
		String msg = isLogin ? getString(R.string.logging) : getString(R.string.not_logging);
		showInToast(msg);
	}

	public void onLogoutButtonClicked(View view) {
		mOpeCenter.logout();
	}

	public void onServerButtonClicked(View view) {
		LayoutInflater inflator = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
		final LinearLayout layout = (LinearLayout) inflator.inflate(R.layout.m4399_demo_select_server_dialog, null);
		GridView sgv = (GridView) layout.findViewById(R.id.m4399_server_gv);
		sgv.setAdapter(new ArrayAdapter<String>(MainActivity.this, R.layout.m4399_demo_server_item, SERVERS));
		sgv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view, int pos, long id) {
				mOpeCenter.setServer(SERVERS[pos]);
				showInToast("进入服务器  " + SERVERS[pos]);
			}
		});
		
		AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
		builder.setTitle("选择服务器").setView(layout).setPositiveButton("Ok", 
				new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
							dialog.dismiss();
					}
		}).create().show();
	}

	//显示当前登录用户信息
	public void onUserButtonClicked(View view) {
		User user = mOpeCenter.getCurrentAccount();
		showInToast(user.toString());
	}

	//删除缓存用户名
	public void onRemoveAccountButtonClicked(View view) {
		LayoutInflater inflator = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
		final LinearLayout layout = (LinearLayout) inflator.inflate(R.layout.m4399_demo_remove_account_dialog, null);
		AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
		builder.setTitle(R.string.delete_account).setView(layout).setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				EditText editText = (EditText) layout.findViewById(R.id.account_edittext);
				boolean result = mOpeCenter.removeCacheAccount(editText.getText().toString());
				String res = result ? getString(R.string.success) : getString(R.string.fail);
				showInToast("Delete account: " + editText.getText().toString() + " " + res);
				dialog.dismiss();
			}
		}).create().show();
	}

	/**
	 * 测试自定义增量更新
	 * 
	 * 自定义增量更新允许开发者定制升级界面
	 * 
	 */
	public void onUpdateButtonClicked(View view) {
		mOpeCenter.doCheck(MainActivity.this, new OnCheckFinishedListener() {

			@Override
			public void onCheckResponse(UpgradeInfo upgradeInfo) {
				Log.d(TAG, "onCheckResponse, " + upgradeInfo);
				showCheckResult(upgradeInfo);
			}
		});
	}
	
	private void showCheckResult(UpgradeInfo info) {
		int code = info.getResultCode();
		final boolean haveLocalSrc = info.haveLocalSrc();
		
		Builder builder = new Builder(MainActivity.this);
		StringBuilder msgBuilder = new StringBuilder();
		
		if (code == UpgradeInfo.APK_CHECK_NO_UPDATE) {
			msgBuilder.append("\n已经是最新版本");
			builder.setNegativeButton("我知道了", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
		} else if (code == UpgradeInfo.APK_CHECK_NEED_UPDATE) {
			msgBuilder.append("\n新版本号: ")
				.append(info.getVersionName() + "-" + info.getVersionCode())
				.append("\n时间: ").append(info.getUpgradeTime())
				.append("\n是否强制更新：").append(info.isCompel())
				.append("\n更新包大小（M）/游戏大小（M）：").append(info.getUpgradeSize() + "/" + info.getNewApkSize())
				.append("\n更新内容：").append(info.getUpgradeMsg());
			String action = haveLocalSrc ? "安装更新包" : "开始更新";
			
			builder.setPositiveButton(action, new DialogInterface.OnClickListener() {

				@Override
				public void onClick(DialogInterface dialog, int which) {
					if (haveLocalSrc)
						mOpeCenter.doInstall(MainActivity.this);
					else
						doDownload();
				}

			}).setNegativeButton("取消更新", new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int which) {
				}

			});
		} else {
			msgBuilder.append("\n检查更新失败");
			msgBuilder.append("\ncode: ").append(code).append("\n失败信息: ").append(info.getResultMsg());
			builder.setNegativeButton("我知道了", new DialogInterface.OnClickListener() {
				
				@Override
				public void onClick(DialogInterface dialog, int which) {
					dialog.dismiss();
				}
			});
		}

		builder.setTitle("自定义更新").setMessage(msgBuilder);
		builder.create().show();
	}
	
	private void doDownload() {
		final ProgressDialog dialog = new ProgressDialog(MainActivity.this);
		dialog.setMessage("准备下载。。。");
		dialog.show();

		mOpeCenter.doDownload(MainActivity.this, new OnDownloadListener() {

			@Override
			public void onDownloadSuccess() {
				Log.d(TAG, "onUpdateSuccess");
				dialog.setMessage("下载成功...");
				doInstall();

				dialog.dismiss();
			}

			@Override
			public void onDownloadFail(int resultCode, String eMsg) {
				Log.d(TAG, "onUpdateFail");
				dialog.setMessage("下载失败...");
				dialog.dismiss();
			}

			@Override
			public void onDownloadStart() {
				Log.d(TAG, "onUpdateStart");
				dialog.setMessage("开始更新...");
			}

			@Override
			public void onDownloadProgress(long progress, long max) {
				long percentage = progress * 100 / max;
				dialog.setMessage("正在更新, 更新进度：" + percentage + "%");
			}
		});
	}
	
	private void doInstall() {
		Builder builder = new Builder(MainActivity.this);
		builder.setTitle("安装更新包").setMessage("是否立即安装更新包？").setPositiveButton("立即安装", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				mOpeCenter.doInstall(MainActivity.this);
			}
		}).setNegativeButton("暂时不用", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});

		builder.create().show();
	}
	
	public void onRechargeButtonClicked(View view) {
		LayoutInflater inflator = (LayoutInflater) getSystemService(LAYOUT_INFLATER_SERVICE);
		final ScrollView sv = (ScrollView) inflator.inflate(R.layout.m4399_demo_recharge_dialog, null);
		AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);

		builder.setTitle(R.string.start_pay).setView(sv).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		}).setPositiveButton("OK", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				// 获取充值金额
				TextView jeTV = (TextView) sv.findViewById(R.id.je);
				String je = jeTV.getText().toString();

				// 获取商品名
				TextView subjectTV = (TextView) sv.findViewById(R.id.subject);
				String productName = subjectTV.getText().toString();
				
				// 生成mark, 支持字母数字和字符‘-’，‘_’，‘|’
				String mark = "year|mon-hour_" + System.currentTimeMillis();
				if (mark.length() > MAX_MARK_LENTH)
					mark = mark.substring(0, MAX_MARK_LENTH);
				//mark = "200570916|95|146044971" + new Random().nextInt(9);

				//是否支持超出金额，这里是一个独立的接口，只要在充值之前调用都有作用
				CheckBox chCB = (CheckBox) sv.findViewById(R.id.changable);
				boolean supportExcess = chCB.isChecked();
				mOpeCenter.setSupportExcess(supportExcess);

				//是否传入商品名，这会影响商品在充值界面的显示
				CheckBox hsCB = (CheckBox) (CheckBox) sv.findViewById(R.id.have_subject);
				boolean hasSubject = hsCB.isChecked();
				if (!hasSubject) {
					productName = null;
				}

				mOpeCenter.recharge(MainActivity.this, Integer.valueOf(je), mark, productName, new OnRechargeFinishedListener() {

					@Override
					public void onRechargeFinished(boolean success, int resultCode, String msg) {
						Log.d(TAG, "Pay: [" + success + ", " + resultCode + ", " + msg + "]");
						showInToast(resultCode + ": " + msg);
					}
				});
				dialog.dismiss();
			}
		}).create().show();
	}

	// 游戏退出
	public void onQuitGameClicked(View view) {
		mOpeCenter.shouldQuitGame(MainActivity.this, new OnQuitGameListener() {

			@Override
			public void onQuitGame(boolean shouldQuit) {
				Log.v(TAG, "Quit game? " + shouldQuit);
				if (shouldQuit) {
				    destroySDK();
				    finish();
					android.os.Process.killProcess(android.os.Process.myPid());
				}
			}
		});
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_BACK)
			onQuitGameClicked(null);
		
		return super.onKeyDown(keyCode, event);
	}
	
	private void showInToast(String msg) {
		Toast.makeText(MainActivity.this, T_PREFFIX + msg, Toast.LENGTH_SHORT).show();
	}
}