package cn.m4399.game.wxapi;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;

import com.tencent.mm.sdk.modelbase.BaseReq;
import com.tencent.mm.sdk.modelbase.BaseResp;
import com.tencent.mm.sdk.openapi.IWXAPI;
import com.tencent.mm.sdk.openapi.IWXAPIEventHandler;
import com.tencent.mm.sdk.openapi.WXAPIFactory;

public class WXPayEntryActivity extends Activity implements IWXAPIEventHandler{
	
    private static final String APP_ID = "wxdf68304f6d87ba2e";
	private static final String TAG = "WXPayEntryActivity";
	private IWXAPI api;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
    	api = WXAPIFactory.createWXAPI(this, APP_ID);
        api.handleIntent(getIntent(), this);
    }

	@Override
	protected void onNewIntent(Intent intent) {
		super.onNewIntent(intent);
		setIntent(intent);
        api.handleIntent(intent, this);
	}

	@Override
	public void onReq(BaseReq req) {
	}

	@Override
	public void onResp(BaseResp resp) {
		String ActionName = getPackageName() + ".ACTION.WX_PAY_RESULT";
		
		Intent intent = new Intent(ActionName);
		intent.putExtra("errCode", resp.errCode);
		intent.putExtra("errStr", resp.errStr);
		boolean success = LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(intent);
		
		Log.v(TAG, "onPayFinish, errCode = " + resp.errCode + ", " + resp.errStr + ", " + ActionName + ", " + success);
		
		finish();
	}
}
